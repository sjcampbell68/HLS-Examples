/*******************************************************************************
Vendor: Xilinx
Associated Filename: bytestrm_dwordproc_test.cpp
Purpose:Vivado HLS Coding Style example
Device: All
Revision History: May 30, 2008 - initial release

*******************************************************************************
#-  (c) Copyright 2011-2018 Xilinx, Inc. All rights reserved.
#-
#-  This file contains confidential and proprietary information
#-  of Xilinx, Inc. and is protected under U.S. and
#-  international copyright and other intellectual property
#-  laws.
#-
#-  DISCLAIMER
#-  This disclaimer is not a license and does not grant any
#-  rights to the materials distributed herewith. Except as
#-  otherwise provided in a valid license issued to you by
#-  Xilinx, and to the maximum extent permitted by applicable
#-  law: (1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND
#-  WITH ALL FAULTS, AND XILINX HEREBY DISCLAIMS ALL WARRANTIES
#-  AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY, INCLUDING
#-  BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-
#-  INFRINGEMENT, OR FITNESS FOR ANY PARTICULAR PURPOSE; and
#-  (2) Xilinx shall not be liable (whether in contract or tort,
#-  including negligence, or under any other theory of
#-  liability) for any loss or damage of any kind or nature
#-  related to, arising under or in connection with these
#-  materials, including for any direct, or any indirect,
#-  special, incidental, or consequential loss or damage
#-  (including loss of data, profits, goodwill, or any type of
#-  loss or damage suffered as a result of any action brought
#-  by a third party) even if such damage or loss was
#-  reasonably foreseeable or Xilinx had been advised of the
#-  possibility of the same.
#-
#-  CRITICAL APPLICATIONS
#-  Xilinx products are not designed or intended to be fail-
#-  safe, or for use in any application requiring fail-safe
#-  performance, such as life-support or safety devices or
#-  systems, Class III medical devices, nuclear facilities,
#-  applications related to the deployment of airbags, or any
#-  other applications that could lead to death, personal
#-  injury, or severe property or environmental damage
#-  (individually and collectively, "Critical
#-  Applications"). Customer assumes the sole risk and
#-  liability of any use of Xilinx products in Critical
#-  Applications, subject only to applicable laws and
#-  regulations governing limitations on product liability.
#-
#-  THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS
#-  PART OF THIS FILE AT ALL TIMES. 
#- ************************************************************************


This file contains confidential and proprietary information of Xilinx, Inc. and
is protected under U.S. and international copyright and other intellectual
property laws.

DISCLAIMER
This disclaimer is not a license and does not grant any rights to the materials
distributed herewith. Except as otherwise provided in a valid license issued to
you by Xilinx, and to the maximum extent permitted by applicable law:
(1) THESE MATERIALS ARE MADE AVAILABLE "AS IS" AND WITH ALL FAULTS, AND XILINX
HEREBY DISCLAIMS ALL WARRANTIES AND CONDITIONS, EXPRESS, IMPLIED, OR STATUTORY,
INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY, NON-INFRINGEMENT, OR
FITNESS FOR ANY PARTICULAR PURPOSE; and (2) Xilinx shall not be liable (whether
in contract or tort, including negligence, or under any other theory of
liability) for any loss or damage of any kind or nature related to, arising under
or in connection with these materials, including for any direct, or any indirect,
special, incidental, or consequential loss or damage (including loss of data,
profits, goodwill, or any type of loss or damage suffered as a result of any
action brought by a third party) even if such damage or loss was reasonably
foreseeable or Xilinx had been advised of the possibility of the same.

CRITICAL APPLICATIONS
Xilinx products are not designed or intended to be fail-safe, or for use in any
application requiring fail-safe performance, such as life-support or safety
devices or systems, Class III medical devices, nuclear facilities, applications
related to the deployment of airbags, or any other applications that could lead
to death, personal injury, or severe property or environmental damage
(individually and collectively, "Critical Applications"). Customer asresultes the
sole risk and liability of any use of Xilinx products in Critical Applications,
subject only to applicable laws and regulations governing limitations on product
liability.

THIS COPYRIGHT NOTICE AND DISCLAIMER MUST BE RETAINED AS PART OF THIS FILE AT
ALL TIMES.

*******************************************************************************/

#include <stdio.h>
#include <iostream>
#include <stdlib.h>
#include "bytestrm_dwordproc.h"

using namespace std;



int main()
{
   int test_data[TESTDATA_LEN];
   int golden_data[TESTDATA_LEN];

   int hw_result;
   int sw_result;

   int err_cnt = 0;

   stream<int> tb2ip_stream;				// stream from TB to IP
   stream<int> ip2tb_stream;				// stream from IP to TB

// ----------------------------------------------------------------------------
// Load/Create input data
// ----------------------------------------------------------------------------

   for (int i = 1; i <= TESTDATA_LEN; i++) {
      test_data[i] = i;
   }

// ----------------------------------------------------------------------------
// Load/Create golden data
// ----------------------------------------------------------------------------

   for (int i = 1; i <= TESTDATA_LEN; i++) {
      golden_data[i] = i * 2 + 1;
   }

// ----------------------------------------------------------------------------
// IP Calling variations
// ----------------------------------------------------------------------------

#ifdef FAILING_EXAMPLE
// ----------------------------------------------------------------------------
// fill input stream with all input
// call IP 1X for all inputs
// read output stream after all IP iterations complete
// ----------------------------------------------------------------------------

   // load all input data into input stream
   for (int i = 1; i <= TESTDATA_LEN; i++) {
          tb2ip_stream << test_data[i];
   }

   // Call IP 1X for all inputs
   cout << "Testbench : " << endl;
   cout << "    in  : tb2ip_stream before    : " << tb2ip_stream.size() << endl;
   cout << "    out : ip2tb_stream before    : " << ip2tb_stream.size() << endl << endl;
   cout << "  call IP() ..." << endl;

   test_stream(tb2ip_stream, ip2tb_stream);

   cout << "    tb2ip_stream after    : " << tb2ip_stream.size() << endl;
   cout << "    ip2tb_stream after    : " << ip2tb_stream.size() << endl;
   cout << endl << endl;


#endif

#ifdef POOR_II_EXAMPLE

   // ----------------------------------------------------------------------------
   // fill input stream with input data 1X per IP call
   // call IP 1X per input sample
   // read output stream after all IP iterations complete
   // ----------------------------------------------------------------------------

   for (int i = 1; i <= TESTDATA_LEN; i++) {
       tb2ip_stream << test_data[i];

	   cout << "--------------------------------------------------------------------------------" << endl;
	   cout << " IP Iteration : " << i << endl;
       cout << "--------------------------------------------------------------------------------" << endl;

       cout << "Testbench : " << endl;
       cout << "    in  : tb2ip_stream before    : " << tb2ip_stream.size() << endl;
       cout << "    out : ip2tb_stream before    : " << ip2tb_stream.size() << endl<<endl;
       cout << "  call IP() ..." << endl;

	   test_stream(tb2ip_stream, ip2tb_stream);

       cout << "    tb2ip_stream after    : " << tb2ip_stream.size() << endl;
       cout << "    ip2tb_stream after    : " << ip2tb_stream.size() << endl;
	   cout << endl << endl;
   }


#endif

#ifdef WORKING_EXAMPLE

   // ----------------------------------------------------------------------------
   // fill input stream with input data 1X per IP call
   // call IP 1X per input sample
   // read output stream after all IP iterations complete
   // ----------------------------------------------------------------------------

   // Initialize stream with all input values to prevent stalls
   for (int i = 1; i <= TESTDATA_LEN; i++) {
       tb2ip_stream << test_data[i];
   }

   for (int i = 1; i <= TESTDATA_LEN; i++) {
	   cout << "--------------------------------------------------------------------------------" << endl;
	   cout << " IP Iteration : " << i << endl;
       cout << "--------------------------------------------------------------------------------" << endl;

       cout << "Testbench : " << endl;
       cout << "    in  : tb2ip_stream before    : " << tb2ip_stream.size() << endl;
       cout << "    out : ip2tb_stream before    : " << ip2tb_stream.size() << endl;
       cout << "  call IP() ..." << endl;

	   test_stream(tb2ip_stream, ip2tb_stream);

       cout << "    tb2ip_stream after    : " << tb2ip_stream.size() << endl;
       cout << "    ip2tb_stream after    : " << ip2tb_stream.size() << endl;
	   cout << endl << endl;
   }



#endif


// ----------------------------------------------------------------------------
// Verify IP Output
// ----------------------------------------------------------------------------

   cout << "Results Analysis:" << endl;

   for (int i = 1; i <= TESTDATA_LEN; i++) {
	   ip2tb_stream >> hw_result;

	   if ( hw_result != golden_data[i] ) {
		   err_cnt++;
		   cout << "    Error: ";
	   } else {
		   cout << "    Pass : ";
	   }

	   cout << "HW : " << hw_result << (( hw_result == golden_data[i]) ? "==" : "!=") << golden_data[i] << endl;
   }



// ----------------------------------------------------------------------------
// Output testbench results
// ----------------------------------------------------------------------------

   if (err_cnt) {
      cout << "!!! ERRORS ENCOUNTERED - Test Fails !!!" << endl;
   } else {
      cout << "*** Test Passes ***" << endl;
   }

   cout << endl << "    ip2tb_stream Final    : " << ip2tb_stream.size() << endl << endl;

   return err_cnt;
}

